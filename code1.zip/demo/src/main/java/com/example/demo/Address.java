package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Address {
public String addressMethod(){
	return "Address Method";
}
}
