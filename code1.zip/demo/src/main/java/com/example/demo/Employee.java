package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component(value="emp")
public class Employee {
	@Autowired
	Address ads;
	public void methodEmployee(){
		System.out.println("Employee Method"+ads.addressMethod());
	}

}
