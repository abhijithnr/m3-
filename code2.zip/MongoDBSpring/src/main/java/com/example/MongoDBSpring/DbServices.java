package com.example.MongoDBSpring;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;




public interface DbServices extends MongoRepository<Employee,Long>{
public ArrayList<Employee> findByAge(int age);
public ArrayList<Employee> findByName(String name);
}
