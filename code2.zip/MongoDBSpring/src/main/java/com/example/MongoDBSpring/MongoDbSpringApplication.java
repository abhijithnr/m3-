package com.example.MongoDBSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoDbSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongoDbSpringApplication.class, args);
	}
}
